﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>

<head>
	<title>KSWEB Web 管理界面</title>
	<meta http-equiv = "Content-Type" content = "text/html; charset=utf-8">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<script src="js/jquery-1.9.1.min.js"></script>
</head>

<body>
