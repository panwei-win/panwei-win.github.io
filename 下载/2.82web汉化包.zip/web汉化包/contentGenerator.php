﻿<? $GLOBALS['_876392599_']=Array(base64_decode('' .'c3RyZWFtX2NvbnRleHRfY3JlYX' .'Rl'),base64_decode('YmFz' .'ZTY0X2VuY29kZ' .'Q=='),base64_decode('Zm' .'l' .'sZV' .'9nZXRfY29' .'udGVudHM='),base64_decode('c3RyX3JlcGxhY2U' .'=')); ?><? function _816214910($i){$a=Array('ZnVuY3Rpb25zLnBocA==','c2VydmVy','bXlzcWw=','cGhw','IC0g','IC0g','IC0g','IC0g','IC0g','IC0g','IC0g','IC0g','PC9hPg==','PC9hPg==','PC9hPg==','PC9hPg==','PC9hPg==','PC9hPg==','PC9hPg==','PC9hPg==','PGEgaHJlZiA9ICdpbmRleC5waHAnPg==','PC9hPg==','ZGF0ZV9vZl9zYXZpbmc=','bGF0aXR1ZGU=','bG9uZ2l0dWRl','YWx0aXR1ZGU=','c3BlZWQ=','aHR0cA==','aGVhZGVy','QXV0aG9yaXphdGlvbjogQmFzaWMg','bG9naW4=','Og==','cGFzc3dvcmQ=','aHR0cDovLw==','bG9jYWxob3N0','MTI3LjAuMC4x','SFRUUF9IT1NU','L3NlcnZlci1zdGF0dXM=','bW92ZV9pbmlz','c2VydmVy','dHJ1ZQ==','cGhw','dHJ1ZQ==','bXlzcWw=','dHJ1ZQ==','cG9ydA==','cm9vdF9kaXI=','ZW5hYmxlX3Jvb3RfZnVuYw==','dHJ1ZQ==','Y2hlY2tlZA==','aXNfc3RhcnRfbWlu','dHJ1ZQ==','Y2hlY2tlZA==','ZW5hYmxlX2dldF9kYXRhX2Zyb21fZ3Bz','dHJ1ZQ==','Y2hlY2tlZA==','ZW5hYmxlX2dwc19sb2dnaW5n','dHJ1ZQ==','Y2hlY2tlZA==','YXV0b19zdGFydA==','dHJ1ZQ==','Y2hlY2tlZA==','bW92ZV9pbmlz','dHJ1ZQ==','Y2hlY2tlZA==','Z290bw==','bXlzcWxfbW9uX3VzZXI=','bXlzcWxfbW9uX3Bhc3M=','aG9zdG5hbWU=','bmFtZQ==','dG90YWw=','IGti','Y2FwYWNpdHk=','JQ==','cXVhbGl0eQ==','dXB0aW1l','dXNhZ2U=','JQ==','ZnJlZQ==','IGti','dm9sdGFnZQ==','IHY=','ZGlzY2FyZGVkX3BhY2tldHM=','c3RhcnRlZF9hdA==','ZmlsbGVk','IGti','c3RhdHVz','bWlzc2VkX3BhY2tldHM=','cmVxdWVzdHM=','dGVtcA==','IEM=','dHJhZmZpYw==','aGVhbHRo','cmVxdWVzdHNfYXZy','dHJhZmZpY19hdnI=');return base64_decode($a[$i]);} ?><?php require_once(_816214910(0));class ContentGenerator{const PAGE_1="1";const PAGE_2="2";const PAGE_3="3";const PAGE_4="4";const PAGE_5="5";const PAGE_6="6";const PAGE_7="7";const PAGE_8="8";var $page_names_array=array("主页","重启KSWEB","KSWEB 设置","服务器状态","服务器设置","MySQL设置","PHP设置","系统设置","GPS设置");function __construct(){}function getContent($page){switch($page){case self::PAGE_1:$this->showRestartServerPage();break;case self::PAGE_2:$this->showKSWEBSettingsPage();break;case self::PAGE_3:$this->showServerStatistics();break;case self::PAGE_4:$this->showConfig(_816214910(1));break;case self::PAGE_5:$this->showConfig(_816214910(2));break;case self::PAGE_6:$this->showConfig(_816214910(3));break;case self::PAGE_7:$this->showSystemConfig();break;case self::PAGE_8:$this->showGPSData();break;default:$this->showGeneralStatistic();}}function getBreadcrums($page){if($page == self::PAGE_1)return $this->generateLink(round(0)) ._816214910(4) .$this->generateLink(self::PAGE_1);if($page == self::PAGE_2)return $this->generateLink(round(0)) ._816214910(5) .$this->generateLink(self::PAGE_2);if($page == self::PAGE_3)return $this->generateLink(round(0)) ._816214910(6) .$this->generateLink(self::PAGE_3);if($page == self::PAGE_4)return $this->generateLink(round(0)) ._816214910(7) .$this->generateLink(self::PAGE_4);if($page == self::PAGE_5)return $this->generateLink(round(0)) ._816214910(8) .$this->generateLink(self::PAGE_5);if($page == self::PAGE_6)return $this->generateLink(round(0)) ._816214910(9) .$this->generateLink(self::PAGE_6);if($page == self::PAGE_7)return $this->generateLink(round(0)) ._816214910(10) .$this->generateLink(self::PAGE_7);if($page == self::PAGE_8)return $this->generateLink(round(0)) ._816214910(11) .$this->generateLink(self::PAGE_8);return $this->generateLink(round(0));}function generateLink($page){if($page == self::PAGE_1)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_1] ._816214910(12);if($page == self::PAGE_2)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_2] ._816214910(13);if($page == self::PAGE_3)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_3] ._816214910(14);if($page == self::PAGE_4)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_4] ._816214910(15);if($page == self::PAGE_5)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_5] ._816214910(16);if($page == self::PAGE_6)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_6] ._816214910(17);if($page == self::PAGE_7)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_7] ._816214910(18);if($page == self::PAGE_8)return"<a href = 'index.php?page=$page'>" .$this->page_names_array[self::PAGE_8] ._816214910(19);return _816214910(20) .$this->page_names_array[round(0)] ._816214910(21);}function showGPSData(){$gpsData=getGPSData(); ?>
			
				<script>
					$(document).ready(function() {  
						
						$("#download_gps_log").click(function(){
							$('.result').css('display', 'none');
							$.post('ajax_handler.php', {act: "download-gps-log"}, function(data) {
								$('.result').html(data);
								$('.result').css('display', 'block');
							});
						});
						
					});
				</script>
			
				<div class = 'result'></div>
			
				<table class = 'table-general-stat' align = "center">
					<tr align = "center">
						<td class = 'title' colspan = "2"><b>最后保存的GPS信息<b></td>
					</tr>
					<tr>
						<td class = 'under-title' align = 'right'>保存日期:</td>
						<td><?php echo $gpsData[_816214910(22)]; ?></td>
					</tr>
					<tr>
						<td class = 'under-title' align = 'right'>纬度:</td>
						<td><?php echo $gpsData[_816214910(23)]; ?></td>
					</tr>
					<tr>
						<td class = 'under-title' align = 'right'>经度:</td>
						<td><?php echo $gpsData[_816214910(24)]; ?></td>
					</tr>
					<tr>
						<td class = 'under-title' align = 'right'>海拔:</td>
						<td><?php echo $gpsData[_816214910(25)]; ?></td>
					</tr>
					<tr>
						<td class = 'under-title' align = 'right'>速度:</td>
						<td><?php echo $gpsData[_816214910(26)]; ?></td>
					</tr>
					<tr>
						<td class = 'under-title' colspan = "2" align = "center"><?php showURLForGPSLogDownloading(); ?></td>
					</tr>
				</table>
			<?php }function showSystemConfig(){ ?>
				<script type='text/javascript' src='js/jquery.base64.min.js'></script>
				<script>
					$(document).ready(function() {  
						
						$("#yes_button").click(function(){
							var old_password = $.base64.encode($('#old_password').val());
							var new_password = $.base64.encode($('#new_password').val());
							var repeat_password = $.base64.encode($('#repeat_password').val());
							
							if (new_password.toString() == repeat_password.toString()) {
								$('.result').css('display', 'none');
								$.post('ajax_handler.php', {act: "save_system_settings", old_password: old_password, new_password: new_password, repeat_password: repeat_password}, function(data) {
									$('.result').html(data);
									$('.result').css('display', 'block');
								});
							
							} else {
								alert("密码错误!");
							}
						});
						
						$("#no_button").click(function(){
							document.location.href = "<?php getFullRootAddress(); ?>?page=0";
						});
						
						
					});
				</script>
				
				<div class = "result"></div>
				<table align = "center">
					<tr>
						<td colspan = 2><b>管理员密码:</b></td>
					</tr>
					<tr>
						<td>旧密码:</td>
						<td><input type = "password" id = "old_password"></td>
					</tr>
					<tr>
						<td>新密码:</td>
						<td><input type = "password" id = "new_password"></td>
					</tr>
					<tr>
						<td>再次确认新密码:</td>
						<td><input type = "password" id = "repeat_password"></td>
					</tr>
				</table>
				
				<div style = "display: block; text-align: center; padding: 25px;">
					<div> 保存更改? </div>
					<img class = "img-button" id = 'yes_button' style = 'padding-right: 25px;' src = 'images/positive.png' width = 32> 
					<img class = "img-button" id = 'no_button' style = 'padding-left: 25px;' src = 'images/negative.png' width = 32> 
				</div>
				
			<?php }function showServerStatistics(){$authInfo=getAuthInfo();$context=$GLOBALS['_876392599_'][0](array(_816214910(27)=> array(_816214910(28)=> _816214910(29) .$GLOBALS['_876392599_'][1]($authInfo[_816214910(30)] ._816214910(31) .$authInfo[_816214910(32)]))));$html=$GLOBALS['_876392599_'][2](_816214910(33) .$GLOBALS['_876392599_'][3](_816214910(34),_816214910(35),$_SERVER[_816214910(36)]) ._816214910(37),false,$context); ?>
				<div style = 'width: 100%; overflow: hidden; overflow-x:scroll;'>
					<?php echo $html; ?>
				</div>
			<?php }function showConfig($whatConfig){ ?>
			<script type='text/javascript' src='js/xedit.js'></script>
			<script type='text/javascript' src='js/jquery.autosize-min.js'></script>
			
			<script>
				$(document).ready(function() {
					xedit.bind($("#config-file-content"), function (el) {
						saveConfig($("#config-file-content").val());
					});

					$('#config-file-content').autosize();   
					
					$("#save-config").click(function(){
						saveConfig($("#config-file-content").val());
					});
					
					function saveConfig(configText) {
						$('.result').css('display', 'none');
						$.post('ajax_handler.php', {act: "save_config", what_config: "<?php echo $whatConfig; ?>", config_text: configText}, function(data) {
							$('.result').html(data);
							$('.result').css('display', 'block');
						});
					}
				});
			</script>
			
			<div class = "result"></div>
			
			<div style = "text-align: right;">
				<a href = "" id = "save-config" onClick = "return false;">保存 (Ctrl + S)</a>
			</div>
			
			<b>正在打开: 
			<?php $settings=getKSWEBSettings();$move_inis=$settings[_816214910(38)];if($whatConfig == _816214910(39)){echo($move_inis == _816214910(40))?SERVERINI_SDCARD_PATH:SERVERINI_PATH;}elseif($whatConfig == _816214910(41)){echo($move_inis == _816214910(42))?PHPINI_SDCARD_PATH:PHPINI_PATH;}elseif($whatConfig == _816214910(43)){echo($move_inis == _816214910(44))?MYSQLINI_SDCARD_PATH:MYSQLINI_PATH;} ?>
			</b>
			<div style = 'width: 100%;'>
				<textarea id = 'config-file-content' style = 'width: 905px; resize: none;'><?php getConfigFileContent($whatConfig,$move_inis); ?></textarea>
			</div>
			<?php }function showKSWEBSettingsPage(){$settings=getKSWEBSettings(); ?>
			
				<script>
			
					$(document).ready(function() {
						var port_old, root_dir_old, enable_root_old, is_start_min_old, auto_start_old, move_inis_old, goto_old, mysql_mon_user_old, mysql_mon_pass_old, enable_get_data_from_gps_old, enable_gps_logging_old;
						
						function initVars() {
							port_old = $('#port').val();
							root_dir_old = $('#root_dir').val();

							$('#is_start_min').is(':checked') ? is_start_min_old = "true" : is_start_min_old = "false";
							$('#auto_start').is(':checked') ? auto_start_old = "true" : auto_start_old = "false";
							$('#move_inis').is(':checked') ? move_inis_old = "true" : move_inis_old = "false";
							
							$('#enable_get_data_from_gps').is(':checked') ? enable_get_data_from_gps_old = "true" : enable_get_data_from_gps_old = "false";
							$('#enable_gps_logging').is(':checked') ? enable_gps_logging_old = "true" : enable_gps_logging_old = "false";
							
							goto_old = $('#goto').val();
							mysql_mon_user_old = $('#mysql_mon_user').val();				
							mysql_mon_pass_old = $('#mysql_mon_pass').val();
						}
					
						initVars();
					
						$("#do_restart_button").click(function(){
							if (checkAllFields()) {
							
								var port = $('#port').val();
								var root_dir = $('#root_dir').val();
								
								var is_start_min;
								$('#is_start_min').is(':checked') ? is_start_min = "true" : is_start_min = "false";		
								
								var auto_start;
								$('#auto_start').is(':checked') ? auto_start = "true" : auto_start = "false";		
								
								var move_inis;
								$('#move_inis').is(':checked') ? move_inis = "true" : move_inis = "false";
								
								var enable_get_data_from_gps;
								$('#enable_get_data_from_gps').is(':checked') ? enable_get_data_from_gps = "true" : enable_get_data_from_gps = "false";
								
								var enable_gps_logging;
								$('#enable_gps_logging').is(':checked') ? enable_gps_logging = "true" : enable_gps_logging = "false";
								
								var goto_ = $('#goto').val();
								var mysql_mon_user = $('#mysql_mon_user').val();				
								var mysql_mon_pass = $('#mysql_mon_pass').val();
								$('.result').css('display', 'none');
								$.post('ajax_handler.php', {act: "save_ksweb_settings", port: port, port_old: port_old, root_dir: root_dir, root_dir_old: root_dir_old, is_start_min: is_start_min, is_start_min_old: is_start_min_old, auto_start: auto_start, auto_start_old: auto_start_old, move_inis: move_inis, move_inis_old: move_inis_old, goto_: goto_, goto_old: goto_old, mysql_mon_user: mysql_mon_user, mysql_mon_user_old: mysql_mon_user_old, mysql_mon_pass: mysql_mon_pass, mysql_mon_pass_old: mysql_mon_pass_old, enable_get_data_from_gps: enable_get_data_from_gps, enable_get_data_from_gps_old: enable_get_data_from_gps_old, enable_gps_logging: enable_gps_logging, enable_gps_logging_old: enable_gps_logging_old}, function(data) {
									$('.result').html(data);
									$('.result').css('display', 'block');
									initVars();
								});
							}
						});
						
						$("#go_back_button").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=0";
						});
						
						$("#move_inis").click(function(){			
							var move_inis;
							$('#move_inis').is(':checked') ? move_inis = "true" : move_inis = "false";
							
							if (move_inis == "true") {
								$('.result').css('display', 'none');
								$.post('ajax_handler.php', {act: "move_inis_click_handler", move_inis: move_inis}, function(data) {
									$('.result').html(data);
									$('.result').css('display', 'block');
								});
							}
							
						});
						
						function checkAllFields() {
							var port = $('#port').val();
							
							if ($('#enable_root_func').is(':checked')) {
								if (port < 2 || port > 65535 || !isNumber(port)) {
									alert('Wrong port number!');
									return false;
								}
							} else {
								if (port < 1024 || port > 65535 || !isNumber(port)) {
									alert('Wrong port number!');
									return false;
								}
							}
							
							return true;
						}
						
						function isNumber(number) {
							if (number == 0) return true;
							return res = (number / number) ? true : false;
						}
						
						
					});		
				</script>
			
				<div class = 'result'></div>
				<div style = 'display: block;'>
					<table align = center>
						<tr>
							<td>端口:</td>
							<td> <input type = 'text' id = 'port' value = '<?php echo $settings[_816214910(45)]; ?>'> </td>
						</tr>
						<tr>
							<td>服务器根目录:</td>
							<td> <input type = 'text' id = 'root_dir' value = '<?php echo $settings[_816214910(46)]; ?>'> </td>
						</tr>
						<tr>
							<td>启用root权限:</td>
							<td><input type="checkbox" id = "enable_root_func" disabled <?php if($settings[_816214910(47)]== _816214910(48))echo _816214910(49); ?>></td>
						</tr>
						<tr>
							<td>KSWEB 最小化启动:</td>
							<td><input type="checkbox" id = "is_start_min" <?php if($settings[_816214910(50)]== _816214910(51))echo _816214910(52); ?>></td>
						</tr>
						<tr>
							<td>GPS 数据采集:</td>
							<td><input type="checkbox" id = "enable_get_data_from_gps" <?php if($settings[_816214910(53)]== _816214910(54))echo _816214910(55); ?>></td>
						</tr>
						<tr>
							<td>GPS 记录:</td>
							<td><input type="checkbox" id = "enable_gps_logging" <?php if($settings[_816214910(56)]== _816214910(57))echo _816214910(58); ?>></td>
						</tr>
						<tr>
							<td>KSWEB 重启后开机自启动:</td>
							<td><input type="checkbox" id = "auto_start" <?php if($settings[_816214910(59)]== _816214910(60))echo _816214910(61); ?>></td>
						</tr>
						<tr>
							<td>使用外部ini文件:</td>
							<td><input type="checkbox" id = "move_inis" <?php if($settings[_816214910(62)]== _816214910(63))echo _816214910(64); ?>></td>
						</tr>
						<tr>
							<td>转到按钮链接:</td>
							<td> <input type = 'text' id = 'goto' value = '<?php echo $settings[_816214910(65)]; ?>'> </td>
						</tr>
						<tr>
							<td>MySQL 用户名:</td>
							<td> <input type = 'text' id = 'mysql_mon_user' value = '<?php echo $settings[_816214910(66)]; ?>'> </td>
						</tr>
						<tr>
							<td>MySQL 密码:</td>
							<td> <input type = 'password' id = 'mysql_mon_pass' value = '<?php echo $settings[_816214910(67)]; ?>'> </td>
						</tr>
					</table>
				</div>
			

			
				<div style = "display: block; text-align: center; padding: 25px;">
					<div> 保存更改? </div>
					<img class = "img-button" id = 'do_restart_button' style = 'padding-right: 25px;' src = 'images/positive.png' width = 32> 
					<img class = "img-button" id = 'go_back_button' style = 'padding-left: 25px;' src = 'images/negative.png' width = 32> 
				</div>
			
			<?php }function showRestartServerPage(){ ?>	
			
				<script>
			
					$(document).ready(function() {
						$("#do_restart_button").click(function(){
							$('.result').css('display', 'none');
							$.post('ajax_handler.php', {act: "restart_server"}, function(data) {
								$('.result').html(data);
								$('.result').css('display', 'block');
							});
						});
						$("#go_back_button").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=0";
						});
					});

				</script>
			
				<div class = "result"></div>
			
				<div class = 'alert'>
					<div>
						<ul style = 'padding-top; 10px; padding-bottom: 10px;'>
							重启前,你必须了解以下事项:
							<li>如果是服务器上的配置文件错误, PHP 或者 MySQL 可能会无法运行. 此时你无法使用 KSWEB Web 管理页面,直到你改正其错误.</li>
							<li>服务器只将重启于 KSWEB服务 在 Android 设备上运行.</li>
							<li>你可能需要确认设备上的root权限,当 "root权限" 选项被启用时.</li>
						</ul>
					</div>
					
					<div style = "display: inline-block; text-align: center; padding: 25px; width: 100%">
						<div> 你确定重启吗? </div>
						<img class = "img-button" id = 'do_restart_button' style = 'padding-right: 25px;' src = 'images/positive.png' width = 32> 
						<img class = "img-button" id = 'go_back_button' style = 'padding-left: 25px;' src = 'images/negative.png' width = 32> 
					</div>
					
				</div>
			<?php }function showMainMenu(){ ?>
			
				<script>
			
					$(document).ready(function() {
						$("#home_page_button").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=0";
						});	
						$("#restart_button").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=1";
						});
						$("#ksweb_settings_button").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=2";
						});
						$("#server_statistics_button").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=3";
						});
						$("#server-settings").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=4";
						});
						$("#mysql-settings").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=5";
						});
						$("#php-settings").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=6";
						});
						$("#system-settings").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=7";
						});
						$("#gps_statistics").click(function(){			
							document.location.href = "<?php getFullRootAddress(); ?>?page=8";
						});
					});			
				</script>
			
				<div class = "main-menu">
					<div class = "menu-element" id = 'home_page_button'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/home.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									主页
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'server_statistics_button'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/statistics.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									服务器状态
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'gps_statistics'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/gps-statistic.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									GPS 状态
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'server-settings'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/server.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									服务器 设置
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'mysql-settings'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/mysql.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									MySQL 设置
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'php-settings'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/php.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									PHP 设置
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'ksweb_settings_button'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/ksweb-settings.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									KSWEB 设置
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'system-settings'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/system-settings.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									系统 设置
								</td>
							</tr>
						</table>
					</div>
					
					<div class = "menu-element" id = 'restart_button'>
						<table>
							<tr>
								<td align = 'center'>
									<img src = 'images/restart.png' width = 64>
								</td>
							</tr>
							<tr>
								<td align = 'center'>
									重启 KSWEB
								</td>
							</tr>
						</table>
					</div>
				</div>
			<?php }function showGeneralStatistic(){$cpu=getCPUInfo();$memoryInfo=getMemInfo();$batteryInfo=getBatteryInfo();$wifiInfo=getWIFIInfo();$serverInfo=getServerInfo(); ?>
			
				<table class = 'table-general-stat' align = 'center' cellspacing = "0">
					
					<tr>
						<td class = 'title' colspan = 10 align = 'center'>
							一般状态
						</td>
					<tr>
					
					<tr>
						<td class = 'title' colspan = 2 align = 'center'>
							<img src = 'images/server.png' width = 64>
						</td>
						<td class = 'title' colspan = 2 align = 'center'>
							<img src = 'images/cpu.png' width = 64>
						</td>
						<td class = 'title' colspan = 2 align = 'center'>
							<img src = 'images/memory.png' width = 64>
						</td>
						<td class = 'title' colspan = 2 align = 'center'>
							<img src = 'images/battery.png' width = 64>
						</td>
						<td class = 'title' colspan = 2 align = 'center'>
							<img src = 'images/wifi.png' width = 64>
						</td>
					<tr>
				
					<tr class = 'table-content'>
						<td align = 'right' class = 'under-title'>
							主机名:
						</td>
						<td>
							<?php echo $serverInfo[_816214910(68)]; ?>
						</td>
					
						<td align = 'right' colspan = 2 class = 'under-title'>
							<?php echo $cpu[_816214910(69)]; ?>
						</td>
						<td align = 'right' class = 'under-title'>
							总量:
						</td>
						<td>
							<?php echo $memoryInfo[_816214910(70)] ._816214910(71); ?>
						</td>
						<td align = 'right' class = 'under-title'>
							电力:
						</td>
						<td>
							<?php echo $batteryInfo[_816214910(72)] ._816214910(73); ?>
						</td>
						<td align = 'right' class = 'under-title'>
							信号状态:
						</td>
						<td>
							<?php echo $wifiInfo[_816214910(74)]; ?>
						</td>
					<tr>
					
					<tr class = 'table-content'>
						<td align = 'right' class = 'under-title'>
							运行时间:
						</td>
						<td>
							<?php echo $serverInfo[_816214910(75)]; ?>
						</td>
					
					
						<td align = 'right' class = 'under-title'>
							CPU 使用量:
						</td>
						<td>
							<?php echo $cpu[_816214910(76)] ._816214910(77); ?>
						</td>
						<td align = 'right' class = 'under-title'>
							闲余:
						</td>
						<td>
							<?php echo $memoryInfo[_816214910(78)] ._816214910(79); ?>
						</td>
						<td align = 'right' class = 'under-title'>
							电压:
						</td>
						<td>
							<?php echo $batteryInfo[_816214910(80)] ._816214910(81); ?>
						</td>
						<td align = 'right' class = 'under-title'>
							丢包:
						</td>
						<td>
							<?php echo $wifiInfo[_816214910(82)]; ?>
						</td>
					<tr>
					
					<tr class = 'table-content'>
						<td align = 'right' class = 'under-title'>
							开始于:
						</td>
						<td>
							<?php echo $serverInfo[_816214910(83)]; ?>
						</td>
					
					
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							占用:
						</td>
						<td>
							<?php echo $memoryInfo[_816214910(84)] ._816214910(85); ?>
						</td>
						<td align = 'right' class = 'under-title'>
							状态:
						</td>
						<td>
							<?php echo $batteryInfo[_816214910(86)]; ?>
						</td>
						
						<td align = 'right' class = 'under-title'>
							漏包:
						</td>
						<td>
							<?php echo $wifiInfo[_816214910(87)]; ?>
						</td>
						
					<tr class = 'table-content'>
						<td align = 'right' class = 'under-title'>
							请求:
						</td>
						<td>
							<?php echo $serverInfo[_816214910(88)]; ?>
						</td>
					
					
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							温度:
						</td>
						<td>
							<?php echo $batteryInfo[_816214910(89)] ._816214910(90); ?>
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
					<tr>
				
					<tr class = 'table-content'>
						<td align = 'right' class = 'under-title'>
							流量:
						</td>
						<td>
							<?php echo $serverInfo[_816214910(91)]; ?>
						</td>
					
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							状态:
						</td>
						<td>
							<?php echo $batteryInfo[_816214910(92)]; ?>
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
					<tr>
					<tr class = 'table-content'>
						<td align = 'right' class = 'under-title'>
							平均请求:
						</td>
						<td>
							<?php echo $serverInfo[_816214910(93)]; ?>
						</td>
					
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
					<tr>
					<tr class = 'table-content'>
						<td align = 'right' class = 'under-title'>
							平均流量:
						</td>
						<td>
							<?php echo $serverInfo[_816214910(94)]; ?>
						</td>
					
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
						<td align = 'right' class = 'under-title'>
							
						</td>
						<td>
							
						</td>
					<tr>
				</table>

			<?php }} ?>