﻿	<div class="footer">
		© KSLabs 团队 2012-2013
	</div>

</body>
</html>